{
  "version": "1.2",
  "dbname": "SRR2838702.ffn",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "Predicted genes sequences for SRR2838702",
  "number-of-letters": 79546,
  "number-of-sequences": 107,
  "last-updated": "2026-10-19T22:42:00",
  "number-of-volumes": 1,
  "bytes-total": 71386,
  "bytes-to-cache": 21372,
  "files": [
    "SRR2838702.ffn.ndb",
    "SRR2838702.ffn.nhr",
    "SRR2838702.ffn.nin",
    "SRR2838702.ffn.not",
    "SRR2838702.ffn.nsq",
    "SRR2838702.ffn.ntf",
    "SRR2838702.ffn.nto"
  ]
}
